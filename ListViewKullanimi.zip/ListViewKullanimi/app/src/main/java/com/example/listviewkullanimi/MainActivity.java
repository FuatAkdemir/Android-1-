package com.example.listviewkullanimi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lw;
    ArrayAdapter<String> diller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ArrayList<String> yazilimDilleri = new ArrayList<>();

        yazilimDilleri.add("php");
        yazilimDilleri.add("java");
        yazilimDilleri.add("c");
        yazilimDilleri.add("c++");
        yazilimDilleri.add("c#");
        yazilimDilleri.add("swift");
        yazilimDilleri.add("objectiv-c");
        yazilimDilleri.add("js");
        yazilimDilleri.add("kotlin");
        yazilimDilleri.add("python");

        diller = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, yazilimDilleri);
        lw = findViewById(R.id.lw);
        lw.setAdapter(diller);

        lw.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),yazilimDilleri.get(position), Toast.LENGTH_LONG ).show();
            }
        });

        lw.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {


                // final yazmamızın sebebi alttaki öğelerden erişmek için. Öteki türlü altını kırmızı çiziyor!
                final AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle(yazilimDilleri.get(position));
                adb.setMessage("Burası Açıklama Alanıdır");

                /*adb.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "evete basıldı", Toast.LENGTH_LONG).show();
                    }
                }); */
                //adb.setNegativeButton("Hayır", null);

                //   kapanmaması için bu kod kullanılabilir:
                //adb.setCancelable(false);

                adb.setPositiveButton("Kapat", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adb.setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialog) {
                                dialog.dismiss();
                            }
                        });
                    }
                });


                adb.create();
                adb.show();

                return false;
            }
        });





    }
}
