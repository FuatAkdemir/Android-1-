package com.example.webview_asset_klasoru_kullanimi;

// Androiddeki En Kolay Uygulama Yöntemi

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wv = findViewById(R.id.wv);
        wv.getSettings().setJavaScriptEnabled(true);


        wv.loadUrl("file:///android_asset/index.html");     // "android içindeki asset klasörü" demek!





    }
}
