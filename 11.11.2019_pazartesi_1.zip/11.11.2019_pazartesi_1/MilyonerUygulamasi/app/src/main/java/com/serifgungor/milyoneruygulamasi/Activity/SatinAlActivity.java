package com.serifgungor.milyoneruygulamasi.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.serifgungor.milyoneruygulamasi.R;

public class SatinAlActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_satin_al);
    }
}
