package com.serifgungor.milyoneruygulamasi.Model;

public class Soru {
    private int soru_id;
    private int soru_suresi;
    private String soru_basligi;
    private String soru_yanit_a;
    private String soru_yanit_b;
    private String soru_yanit_c;
    private String soru_yanit_d;
    private String soru_yanit_harf;

    public Soru() {
    }

    public Soru(int soru_id, int soru_suresi, String soru_basligi, String soru_yanit_a, String soru_yanit_b, String soru_yanit_c, String soru_yanit_d, String soru_yanit_harf) {
        this.soru_id = soru_id;
        this.soru_suresi = soru_suresi;
        this.soru_basligi = soru_basligi;
        this.soru_yanit_a = soru_yanit_a;
        this.soru_yanit_b = soru_yanit_b;
        this.soru_yanit_c = soru_yanit_c;
        this.soru_yanit_d = soru_yanit_d;
        this.soru_yanit_harf = soru_yanit_harf;
    }

    public int getSoru_id() {
        return soru_id;
    }

    public void setSoru_id(int soru_id) {
        this.soru_id = soru_id;
    }

    public int getSoru_suresi() {
        return soru_suresi;
    }

    public void setSoru_suresi(int soru_suresi) {
        this.soru_suresi = soru_suresi;
    }

    public String getSoru_basligi() {
        return soru_basligi;
    }

    public void setSoru_basligi(String soru_basligi) {
        this.soru_basligi = soru_basligi;
    }

    public String getSoru_yanit_a() {
        return soru_yanit_a;
    }

    public void setSoru_yanit_a(String soru_yanit_a) {
        this.soru_yanit_a = soru_yanit_a;
    }

    public String getSoru_yanit_b() {
        return soru_yanit_b;
    }

    public void setSoru_yanit_b(String soru_yanit_b) {
        this.soru_yanit_b = soru_yanit_b;
    }

    public String getSoru_yanit_c() {
        return soru_yanit_c;
    }

    public void setSoru_yanit_c(String soru_yanit_c) {
        this.soru_yanit_c = soru_yanit_c;
    }

    public String getSoru_yanit_d() {
        return soru_yanit_d;
    }

    public void setSoru_yanit_d(String soru_yanit_d) {
        this.soru_yanit_d = soru_yanit_d;
    }

    public String getSoru_yanit_harf() {
        return soru_yanit_harf;
    }

    public void setSoru_yanit_harf(String soru_yanit_harf) {
        this.soru_yanit_harf = soru_yanit_harf;
    }
}
