package com.example.startactivityforresult2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    Button btnElma, btnArmut, btnMuz, btnKarpuz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnArmut = findViewById(R.id.btnArmut);
        btnElma = findViewById(R.id.btnElma);
        btnMuz = findViewById(R.id.btnMuz);
        btnKarpuz = findViewById(R.id.btnKarpuz);

        btnElma.setOnClickListener(this);
        btnArmut.setOnClickListener(this);
        btnMuz.setOnClickListener(this);
        btnKarpuz.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String isim = "";
        Intent intent = new Intent(getApplicationContext(), SonucActivity.class);
        intent.putExtra("isim", isim);

        if (v.getId() == R.id.btnElma){
            isim = "elma";
            startActivityForResult(intent, 100);
        }
        else if (v.getId() == R.id.btnArmut){
            isim = "armut";
            startActivityForResult(intent, 200);
        }
        else if (v.getId() == R.id.btnMuz){
            isim = "muz";
            startActivityForResult(intent, 300);
        }
        else if (v.getId() == R.id.btnKarpuz){
            isim = "karpuz";
            startActivityForResult(intent, 400);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode){
            case 100:
                Toast.makeText(getApplicationContext(),"Elma", Toast.LENGTH_LONG).show();
                break;
            case 200:
                Toast.makeText(getApplicationContext(),"Armut", Toast.LENGTH_LONG).show();
                break;
            case 300:
                Toast.makeText(getApplicationContext(),"Muz", Toast.LENGTH_LONG).show();
                break;
            case 400:
                Toast.makeText(getApplicationContext(),"Karpuz", Toast.LENGTH_LONG).show();
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);

    }
}
