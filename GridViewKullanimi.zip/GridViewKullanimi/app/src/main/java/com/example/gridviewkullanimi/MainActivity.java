package com.example.gridviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    GridView gv;
    ArrayAdapter<String> adapter;
    ArrayList<String> liste;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gv = findViewById(R.id.gv);
        liste = new ArrayList<>();
        liste.add("Elma");
        liste.add("Armut");
        liste.add("Şeftali");
        liste.add("Muz");
        liste.add("Karpuz");
        liste.add("Kavun");
        liste.add("Kivi");
        liste.add("Nar");

        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, liste);
        // GridView kolon sayısını xml'de girmek yerine buradan da set edebiliriz.
        gv.setNumColumns(4);

        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Yazı", Toast.LENGTH_LONG).show();
            }
        });


    }
}
