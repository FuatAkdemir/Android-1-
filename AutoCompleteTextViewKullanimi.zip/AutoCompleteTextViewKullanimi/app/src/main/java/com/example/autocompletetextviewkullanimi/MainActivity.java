package com.example.autocompletetextviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView actv;
    MultiAutoCompleteTextView mactv;

    ArrayList<String> sehirler = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sehirler.add("Ankara");
        sehirler.add("Antalya");
        sehirler.add("Konya");
        sehirler.add("Kocaeli");
        sehirler.add("Sinop");
        sehirler.add("Sivas");

        arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line, sehirler);


        actv = findViewById(R.id.actv);
        actv.setAdapter(arrayAdapter);
        //actv.setThreshold(3); ilk 3 karakterden sonra sorgulama yapması için kullanılır. Mesela database'i yormaması için kullanılabilir.

        mactv = findViewById(R.id.mactv);
        mactv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        mactv.setAdapter(arrayAdapter);



    }
}
