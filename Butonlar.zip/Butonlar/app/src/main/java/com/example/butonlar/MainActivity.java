package com.example.butonlar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {




    public void butonaTikla(View view){

        if(view.getId() == R.id.btn1){
            Toast.makeText(getApplicationContext(), "Buton 1'den geldim", Toast.LENGTH_LONG).show();

        }else if(view.getId() == R.id.btn2){
            Toast.makeText(getApplicationContext(), "Buton 2'den geldim", Toast.LENGTH_LONG).show();

        }else if(view.getId() == R.id.btn3){
            Toast.makeText(getApplicationContext(), "Buton 3'den geldim", Toast.LENGTH_LONG).show();

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




    }
}
