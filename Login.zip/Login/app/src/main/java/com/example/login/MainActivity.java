package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    Button btn;
    EditText etUser, etPass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUser.getText().toString();
                String password = etPass.getText().toString();

                if ("root".equals(username) && "1234".equals(password)) {
                    Toast.makeText(getApplicationContext(), "Hoşgeldiniz", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Hatalı Giriş!", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}
