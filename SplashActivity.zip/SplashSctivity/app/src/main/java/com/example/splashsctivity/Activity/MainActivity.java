package com.example.splashsctivity.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.splashsctivity.R;

public class MainActivity extends AppCompatActivity {
    ListView kategoriler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Bilmeceler");    // Toolbar'ın başlığını değiştirir.
        kategoriler = findViewById(R.id.listViewKategoriler);



    }

    // Menü oluşturmak için kullanılır.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu); // menu_main.xml dosyasını toolbar'dagösterir.
        return super.onCreateOptionsMenu(menu);
    }

    // Menü item'ına tıklama olayını yakalamak için kullanılır.
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.id_ayarlar){
            startActivity(new Intent(getApplicationContext(), AyarlarActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }




}
