package com.example.splashsctivity.Adapter;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.splashsctivity.Model.Kategori;

import java.util.ArrayList;

public class KategoriAdapter extends BaseAdapter {

    private LayoutInflater layoutInflater;
    private Context contex;
    private ArrayList<Kategori> kategoriler;

    public KategoriAdapter() {
    }

    public KategoriAdapter(Context contex, ArrayList<Kategori> kategoriler) {
        this.layoutInflater = (LayoutInflater) contex.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.contex = contex;
        this.kategoriler = kategoriler;
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Kategori getItem(int position) { //Object olarak da kalabilir. Orijinalde Object
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }


}
