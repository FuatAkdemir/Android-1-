package com.example.switchcheckboxradiobuton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    CheckBox chk;
    ToggleButton tg;
    Switch sw;
    RadioButton rberkek, rbkadin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chk = findViewById(R.id.checkBox);
        tg = findViewById(R.id.toggleButton);
        sw = findViewById(R.id.switch1);
        rberkek = findViewById(R.id.erkek);
        rbkadin = findViewById(R.id.kadin);


        chk.setChecked(true);
        tg.setChecked(true);
        sw.setChecked(true);


        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    Log.d("durum", "checkbox aktif edildi");
                }
                else Log.d("durum", "checkbox pasif");

            }
        });

        tg.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("durum", "toggle aktif edildi");
                }
                else Log.d("durum", "toggle pasif");

            }
        });

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("durum", "switch aktif edildi");
                }
                else Log.d("durum", "switch pasif");

            }
        });

        rberkek.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("durum", "erkek seçildi");
                }
                else Log.d("durum", "erkek seçimi iptal edildi");
            }
        });

        rbkadin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("durum", "kadın seçildi");
                }
                else Log.d("durum", "kadın seçimi iptal edildi");
            }
        });



    }
}
