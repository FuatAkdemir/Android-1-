package com.example.butonatiklama3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btn;
    ImageView ivResim;

    int sayi = 0;
    int[] resimler = new int[8];



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btnTikla);
        ivResim = findViewById(R.id.ivResim);

        resimler[0] = R.drawable.kedi;
        resimler[1] = R.drawable.kopek;
        resimler[2] = R.drawable.balik;
        resimler[3] = R.drawable.deve;
        resimler[4] = R.drawable.kus;
        resimler[5] = R.drawable.devekusu;
        resimler[6] = R.drawable.kopekbaligi;


        ivResim.setImageResource(R.drawable.kedi);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (sayi == 7){
                    sayi = 0;
                }
                else{
                    sayi += 1;
                }

                ivResim.setImageResource(resimler[sayi]);

            }
        });


    }


}
