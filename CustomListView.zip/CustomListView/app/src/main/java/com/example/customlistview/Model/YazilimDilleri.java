package com.example.customlistview.Model;

public class YazilimDilleri {

    private String isim;
    private String aciklama;
    private int resim;

    /*
    Kapsülleme ilkesi kuralları:

    1) Değişkenlerin (Field'ların) private üretilmesi
    2) Her değişken için get ve set metotlar üretilmesi
    3) Boş ve dolu constructor üretilmesi
     */

    // Boş constructor ürettik:
    // Sağ click generate constructor, select none
    public YazilimDilleri() {
    }

    // Dolu constructor ürettik:
    // Sağ click generate constructor ctrl+a ok
    public YazilimDilleri(String isim, String aciklama, int resim) {
        this.isim = isim;
        this.aciklama = aciklama;
        this.resim = resim;
    }

    // getter'lar
    // sağ click generate getter ok
    public String getIsim() {
        return isim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public int getResim() {
        return resim;
    }

    // setter'lar
    // sağ click generate setter ok
    public void setIsim(String isim) {
        this.isim = isim;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }










}
