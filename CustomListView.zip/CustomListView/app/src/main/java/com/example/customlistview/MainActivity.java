package com.example.customlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.customlistview.Adapter.YazilimDilleriAdapter;
import com.example.customlistview.Model.YazilimDilleri;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    ListView listView;

    YazilimDilleriAdapter adapter;
    ArrayList<YazilimDilleri> yazilimDilleriArrayList = new ArrayList<>();                                       //


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        yazilimDilleriArrayList.add(new YazilimDilleri("Java", "Java açıklaması", R.drawable.java));
        yazilimDilleriArrayList.add(new YazilimDilleri("Python", "Python açıklaması",  R.drawable.python));
        yazilimDilleriArrayList.add(new YazilimDilleri("Php", "Php açıklaması",  R.drawable.php));
        yazilimDilleriArrayList.add(new YazilimDilleri("C", "C açıklaması",  R.drawable.c));
        yazilimDilleriArrayList.add(new YazilimDilleri("Kotlin", "Kotlin açıklaması",  R.drawable.kotlin));
        yazilimDilleriArrayList.add(new YazilimDilleri("C++", "C++ açıklaması", R.drawable.cpp));
        yazilimDilleriArrayList.add(new YazilimDilleri("Html", "Html açıklaması",  R.drawable.html));
        yazilimDilleriArrayList.add(new YazilimDilleri("Css", "Css açıklaması",  -1));

        adapter = new YazilimDilleriAdapter(getApplicationContext(), yazilimDilleriArrayList);
        listView.setAdapter(adapter);



    }
}
