package com.example.milyoneruygulamas.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.milyoneruygulamas.Model.Soru;
import com.example.milyoneruygulamas.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Random;
import java.util.Timer;

public class OynaActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnA, btnB, btnC, btnD, cekil;
    TextView tvSoru, sayac;
    ImageView ivSeyirciJokeri, ivYariYariya, ivTlfJokeri;
    LinearLayout linearLayoutSeviyeler;
    String[] seviyeler;

    int index = 0;
    String tarih;
    int tlf_jokeri = 0;
    int seyirci_jokeri = 0;
    int yariyariya_jokeri = 0;
    int oyundan_cekildimi = 0;
    String toplam_kazanc = "";
    int oyunda_gecen_sure = 0;

    //AdView adView;
    //private InterstitialAd mIntersititialAd; // Tam sayfa reklam göstermek için kullanılan sınıftır.

    Dialog dialog;
    MediaPlayer mySound;

    SharedPreferences sp;
    SharedPreferences.Editor spe;
    ArrayList<Soru> sorular;

    public void yanitKontrol(String harf, int index){
        if(harf.equals(sorular.get(index).getSoru_yanit_harf())){
            if(index<11){
                index += 1;
                soruyuGetir(index);
                soruYanitDogruSes();
            }
        }
        else{
            // Oyunu Bitir
            oyunuBitir("Yanlış yanıt verdiniz !\nOyun bitti...");
            soruYanitYanlisSes();
        }
    }

    public void reklamGetir(){
        int reklamSayi = sp.getInt("reklamSayi", 0);
        if(reklamSayi>2){
            // Reklam göster
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            if(mIntersititialAd.isLoaded()){    // Eğer reklam yüklendiyse
                mIntersititialAd.show();        // Tam sayfa reklamı göster.
            }
            else{
                Log.d("UYARI", "Reklam henüz yüklenmedi");
            }

            spe.putInt("reklamSayi", 0);
            spe.commit();
        }
    }

    public void seviyeleriGetir(String[] seviyeler){
        for (int i = 0; i<12; i++){
            TextView tvSeviye = new TextView(getApplicationContext());
            tvSeviye.setText(seviyeler[i]);
            tvSeviye.setId(i);
            tvSeviye.setTextSize(16);
            tvSeviye.setTextColor(Color.parseColor("#ffffff"));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,90);
            params.setMargins(0, 0, 0, 20);
            tvSeviye.setLayoutParams(params);
            tvSeviye.setGravity(Gravity.CENTER);

            if (i == 1 || i==6 || i == 11){
                tvSeviye.setBackgroundResource(R.drawable.button_style3);
            }
            else{
                tvSeviye.setBackgroundResource(R.drawable.button_style2);
            }

            linearLayoutSeviyeler.addView(tvSeviye);
        }
    }

    public void seviyeleriTemizle(){
        for (int i = 0; i<linearLayoutSeviyeler.getChildCount(); i++){
            TextView seviye = (TextView) linearLayoutSeviyeler.getChildAt(i);
            if(i == 1 || i == 6 || i == 11){
                seviye.setBackgroundResource(R.drawable.button_style3);

            }
            else if(i == 0){    // ilk soru seçili gelecek
                // selected
                seviye.setBackgroundResource(R.drawable.button_style4);

            }else{
                seviye.setBackgroundResource(R.drawable.button_style1);
            }
        }
    }

    public void tumButonlariGeriGetir(){
        btnA.setVisibility(View.VISIBLE);    // resmi göster
        btnB.setVisibility(View.VISIBLE);
        btnC.setVisibility(View.VISIBLE);
        btnD.setVisibility(View.VISIBLE);
    }

    public ArrayList<Soru> sorularıGetir(){
        ArrayList<Soru> sorular = new ArrayList<>();

        for (int i = 0; i<12; i++){
            sorular.add(
                    new Soru(
                        i,
                        0,
                        "Soru başlığı" + i,
                        "Yanıt a" + i,
                        "Yanıt b" + i,
                        "Yanıt c" + i,
                        "Yanıt d" + i,
                        "a"
                    )
            );
        }
        return sorular;
    }

    public void soruyuGetir(int index){
         btnA.setText("" + sorular.get(index).getSora_yanit_a());
         btnB.setText("" + sorular.get(index).getSora_yanit_b());
         btnC.setText("" + sorular.get(index).getSora_yanit_c());
         btnD.setText("" + sorular.get(index).getSora_yanit_d());
         tvSoru.setText("" + sorular.get(index).getSoru_basligi());

         if (index != 0){
             TextView tvBirOncekiIndex = (TextView) linearLayoutSeviyeler.getChildAt(index-1);
             tvBirOncekiIndex.setBackgroundResource(R.drawable.button_style2);

             if((index-1) == 1 || (index-1) == 6 || (index-1) == 11){
                 tvBirOncekiIndex.setBackgroundResource(R.drawable.button_style3);
             }

             TextView tvSuankiSoru = (TextView) linearLayoutSeviyeler.getChildAt(index);
             tvSuankiSoru.setBackgroundResource(R.drawable.button_style4);
         }
         else {    // seçili sorunun indisi 0'dır. yani ilk soru
             TextView tv = (TextView) linearLayoutSeviyeler.getChildAt(index);
             tv.setBackgroundResource(R.drawable.button_style4);
         }
    }

    public void oyunuBitir(String yazi){

        this.dialog = new Dialog(OynaActivity.this);
        dialog.setContentView(R.layout.dialog_oyunubitir);
        dialog.setCancelable(false); // boşluğa tıklarsa dialog kapatamasın.

        TextView tvYazi = dialog.findViewById(R.id.tvDialogYazi);
        Button btnBitir = dialog.findViewById(R.id.btnBitir);
        Button btnYenidenOyna = dialog.findViewById(R.id.btnYenidenOyna);
        tvYazi.setText(yazi);

        if (!dialog.isShowing()){
            dialog.show();
        }

        btnBitir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Veritabanına skor ekleme yapılsın.
                spe.putInt("reklamSayi", sp.getInt("reklamSayi", 0) +1);
                spe.commit();
                reklamGetir();
                dialog.dismiss();   // dialog nesnesini kapat
                finish();
            }
        });

        btnYenidenOyna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yenidenOyna();
                dialog.dismiss();   // dialog nesnesini kapat
            }
        });

        btnYenidenOyna.setOnClickListener(this);
    }

    public void yenidenOyna(){
        ivSeyirciJokeri.setVisibility(View.VISIBLE);    // resmi göster
        ivTlfJokeri.setVisibility(View.VISIBLE);
        ivYariYariya.setVisibility(View.VISIBLE);

        index = 0;
        sorular = sorularıGetir();
        soruyuGetir(0);
        //timer.cancel();
        sureyiSay();
        seviyeleriTemizle();
        tarih = new Date().toString();
        tlf_jokeri = 0;
        seyirci_jokeri = 0;
        yariyariya_jokeri = 0;
        toplam_kazanc = "";
        oyunda_gecen_sure = 0;
        tumButonlariGeriGetir();
        spe.putInt("reklamSayi", sp.getInt("reklamSayi", 0) +1);
        spe.commit();
        reklamGetir();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyna);
        this.getSupportActionBar().hide();

        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);
        cekil = findViewById(R.id.cekil);
        tvSoru = findViewById(R.id.tvSoru);

        btnA.setOnClickListener(this);
        btnB.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnD.setOnClickListener(this);
        cekil.setOnClickListener(this);

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();

        //MobileAds.initialize(this, "ca-app-pub- -");
        //mInterstitialAt = new InterstitialAt(this);
        //mIntersititialAt.setAdUnitId("ca-app-pub-");

        sayac = findViewById(R.id.tvSayac);

        ivSeyirciJokeri = findViewById(R.id.seyirciJokeri);
        ivYariYariya = findViewById(R.id.yariyariyaJokeri);
        linearLayoutSeviyeler = findViewById(R.id.linearLayoutSeviyeler);
        ivTlfJokeri = findViewById(R.id.tlfJokeri);

        seviyeler = new String[]{"1.000.000 TL", "250.000 TL", "125.000 TL", "60.000 TL", "30.000 TL", "15.000 TL",  "7.500 TL", "5.000 TL", "3.000 TL", "2.000 TL", "1.000 TL", "500 TL"};
        seviyeleriGetir(seviyeler);

        seviyeleriTemizle();

        sorular = sorularıGetir(0);
        oyunaBaslaSes();
        ivYariYariya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String harf = sorular.get(index).getSoru_yanit_harf();
                rastgeleHYanitGertir_yariYariyaJoker(harf);
                yariyariya_jokeri = 1;

            }
        });

        btnOyundanCekil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String harf = sorular.get(index).getSoru_yanit_harf();
                rastgeleHYanitGertir_yariYariyaJoker(harf);
                yariyariya_jokeri = 1;

            }
        });


        ivYariYariya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (index == 0){
                    oyunuBitir("Oyundan çekildiniz.\n Kazancınız 0 TL");
                }
                else{
                    String kazanc = seviyeler[index -1];
                    oyunuBitir("Oyundan çekildiniz.\n Kazancınız: " + kazanc);
                }

                timerGeriSayac.cancel();
                timerOyundaGecenSure.cancel();
                oyundan_cekildimi = 1;
                spe.putInt("reklamSayi", sp.getInt("reklamSayi", 0)+1);
                spe.commit();
                reklamGetir();

            }
        });

        timerGeriSayac = new Timer();
        sureyiSay

    }

    public void soruYanitDogruSes(){
        mySound = MediaPlayer.create(this,R.raw.correct);
        if(!mySound.isPlaying()){
            mySound.start();
        }
    }

    public void soruYanitYanlisSes(){
        mySound = MediaPlayer.create(this,R.raw.lose);
        if(!mySound.isPlaying()){
            mySound.start();
        }
    }

    public void oyunaBaslaSes(){
        mySound = MediaPlayer.create(this,R.raw.barajbir);
        if(!mySound.isPlaying()){
            mySound.start();
        }
    }

    public void rastgeleHYanitGertir_yariYariyaJoker(String dogruYanitHarf){
        Random rnd = new Random();
        ArrayList<String> harf = new ArrayList<>();
        int yanlisHarf = rnd.nextInt(3);
        harf.add("a");
        harf.add("b");
        harf.add("c");
        harf.add("d");
        harf.remove(dogruYanitHarf);

        ArrayList<Button> butonlar = new ArrayList<>();
        butonlar.add(btnA);


        if("a".equals(dogruYanitHarf)){
            harf.remove("a");
            btnA.setVisibility(View.VISIBLE);
        }
        else if("b".equals(dogruYanitHarf)){
            harf.remove("b");
            btnB.setVisibility(View.VISIBLE);
        }
        else if("c".equals(dogruYanitHarf)){
            harf.remove("c");
            btnC.setVisibility(View.VISIBLE);
        }
        else if("d".equals(dogruYanitHarf)){
            harf.remove("d");
            btnD.setVisibility(View.VISIBLE);
        }

        Collections.shuffle(harf);  // ArrayList'teki elemanların sırasını karıştırır.
                                    // Böylece doğru şık her zaman aynı şıkta durmaz.

        // Random ile rastgele 0 - 3 arası değer ürettirdik ve bu int değişkene yanlisHarf ismini verdik.

        if("a".equals(harf.get(yanlisHarf))){
            btnA.setVisibility(View.VISIBLE);
            btnA.setVisibility(View.VISIBLE);
            btnA.setVisibility(View.VISIBLE);

        }
        else if("b".equals(harf.get(yanlisHarf))){
            btnB.setVisibility(View.VISIBLE);
        }
        else if("c".equals(harf.get(yanlisHarf))){
            btnC.setVisibility(View.VISIBLE);
        }
        else if("d".equals(harf.get(yanlisHarf))){
            btnD.setVisibility(View.VISIBLE);
        }


    }

    @Override
    public void onClick(View v) {

        Button btn = (Button) v;
        tumButonlariGeriGetir();

        if(index == 11){
            oyunuBitir("Tebrikler\nOyunu bitirdiniz\nÖdülünüz: 1.000.000 TL");
        }

        if(v.getId() == R.id.btnA){
            yanitKontrol("a", index);
        }
        else if(v.getId() == R.id.btnB){
            yanitKontrol("b", index);
        }
        else if(v.getId() == R.id.btnC){
            yanitKontrol("c", index);
        }
        else if(v.getId() == R.id.btnD){
            yanitKontrol("d", index);
        }
    }
}



