package com.example.milyoneruygulamas;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OynaActivity extends AppCompatActivity {

    Button btnA, btnB, btnC, btnD;
    TextView soru, sayac;
    ImageView ivSeyirciJokeri, ivYariYariya, ivTlfJokeri;
    LinearLayout linearLayoutSeviyeler;

    public void seviyeleriGetir(String[] seviyeler){
        for (int i = 0; i<12; i++){
            TextView tvSeviye = new TextView(getApplicationContext());
            tvSeviye.setText(seviyeler[i]);
            tvSeviye.setId(i);
            tvSeviye.setTextSize(20);
            tvSeviye.setTextColor(Color.parseColor("#ffffff"));

            linearLayoutSeviyeler.addView(tvSeviye);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyna);

        this.getSupportActionBar().hide();

        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);

        sayac = findViewById(R.id.tvSayac);
        soru = findViewById(R.id.tvSoru);

        ivSeyirciJokeri = findViewById(R.id.seyirciJokeri);
        ivYariYariya = findViewById(R.id.yariyariyaJokeri);
        linearLayoutSeviyeler = findViewById(R.id.linearLayoutSeviyeler);
        ivTlfJokeri = findViewById(R.id.tlfJokeri);


        String[] seviyeler = {"500 TL", "1000 TL", "2000 TL", "3000 TL", "5000 TL", "7500 TL", "15000 TL", "30000 TL", "60000 TL", "125000 TL", "250 000 TL", "1000000 TL"};
        seviyeleriGetir(seviyeler);

    }



}



