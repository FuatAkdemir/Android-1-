package com.example.milyoneruygulamas.Model;

public class Soru {
    private int soru_id;
    private int soru_suresi;
    private String soru_basligi;
    private String sora_yanit_a;
    private String sora_yanit_b;
    private String sora_yanit_c;
    private String sora_yanit_d;
    private String soru_yanit_harf;


    public Soru() {
    }

    public Soru(int soru_id, int soru_suresi, String soru_basligi, String sora_yanit_a, String sora_yanit_b, String sora_yanit_c, String sora_yanit_d, String soru_yanit_harf) {
        this.soru_id = soru_id;
        this.soru_suresi = soru_suresi;
        this.soru_basligi = soru_basligi;
        this.sora_yanit_a = sora_yanit_a;
        this.sora_yanit_b = sora_yanit_b;
        this.sora_yanit_c = sora_yanit_c;
        this.sora_yanit_d = sora_yanit_d;
        this.soru_yanit_harf = soru_yanit_harf;
    }

    public int getSoru_id() {
        return soru_id;
    }

    public void setSoru_id(int soru_id) {
        this.soru_id = soru_id;
    }

    public int getSoru_suresi() {
        return soru_suresi;
    }

    public void setSoru_suresi(int soru_suresi) {
        this.soru_suresi = soru_suresi;
    }

    public String getSoru_basligi() {
        return soru_basligi;
    }

    public void setSoru_basligi(String soru_basligi) {
        this.soru_basligi = soru_basligi;
    }

    public String getSora_yanit_a() {
        return sora_yanit_a;
    }

    public void setSora_yanit_a(String sora_yanit_a) {
        this.sora_yanit_a = sora_yanit_a;
    }

    public String getSora_yanit_b() {
        return sora_yanit_b;
    }

    public void setSora_yanit_b(String sora_yanit_b) {
        this.sora_yanit_b = sora_yanit_b;
    }

    public String getSora_yanit_c() {
        return sora_yanit_c;
    }

    public void setSora_yanit_c(String sora_yanit_c) {
        this.sora_yanit_c = sora_yanit_c;
    }

    public String getSora_yanit_d() {
        return sora_yanit_d;
    }

    public void setSora_yanit_d(String sora_yanit_d) {
        this.sora_yanit_d = sora_yanit_d;
    }

    public String getSoru_yanit_harf() {
        return soru_yanit_harf;
    }

    public void setSoru_yanit_harf(String soru_yanit_harf) {
        this.soru_yanit_harf = soru_yanit_harf;
    }




}
