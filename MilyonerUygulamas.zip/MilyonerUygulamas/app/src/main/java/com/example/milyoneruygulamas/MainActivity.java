package com.example.milyoneruygulamas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.QuickContactBadge;

public class MainActivity extends AppCompatActivity {

    Button btnBasla, btnBasarilar, btnSkorlar, btnSatinAl, btnCikis;
    ImageView ivSound;
    int sayi = 0;
    SharedPreferences sp;
    SharedPreferences.Editor spe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.getSupportActionBar().hide();
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();


        btnBasla = findViewById(R.id.btnBasla);
        btnBasarilar = findViewById(R.id.btnBasarilar);
        btnSkorlar = findViewById(R.id.btnSkorlar);
        btnSatinAl = findViewById(R.id.btnSatinAl);
        btnCikis = findViewById(R.id.btnCikis);
        ivSound = findViewById(R.id.ivSound);

        if (sp.getInt("sound", 1) == 0){
            ivSound.setImageResource(R.drawable.ic_on);
        }else if(sp.getInt("sound", 1) == 1){
            ivSound.setImageResource(R.drawable.ic_off);
        }

        ivSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sayi == 0){
                    sayi = 1;
                    ivSound.setImageResource(R.drawable.ic_off);
                }
                else if (sayi == 1){
                    sayi = 0;
                    ivSound.setImageResource(R.drawable.ic_on);
                }

                spe.putInt("sound", sayi);
                spe.commit();

            }
        });

        btnBasla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),OynaActivity.class);
                startActivity(i);


            }
        });

        btnBasarilar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

        btnSkorlar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

        btnSatinAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

        btnCikis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();

            }
        });


    }
}
