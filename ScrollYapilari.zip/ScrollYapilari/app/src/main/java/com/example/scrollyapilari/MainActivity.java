package com.example.scrollyapilari;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    LinearLayout LinLay;

    // __________________ PROGRAMATİK OLARAK NESNE ÜRETME ______________________

    public void nesneUret(String nesne, String nesneAdi){

        if("textview".equals(nesne)){
            TextView tv = new TextView(getApplicationContext());
            tv.setText("" + nesneAdi);
            LinLay.addView(tv);

        }else if("button".equals(nesne)){
            Button btn = new Button(getApplicationContext());
            btn.setText("" + nesneAdi);
            LinLay.addView(btn);

        }else if("checkbox".equals(nesne)){
            CheckBox cb = new CheckBox(getApplicationContext());
            cb.setText("" + nesneAdi);
            LinLay.addView(cb);

        }else if("edittext".equals(nesne)){
            EditText et = new EditText(getApplicationContext());
            et.setText("" + nesneAdi);
            LinLay.addView(et);

        }


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinLay = findViewById(R.id.LinLayout);

        nesneUret("button","Buton 1" );
        nesneUret("button","Buton 2" );
        nesneUret("checkbox", "checkbox 1");
        nesneUret("button","Buton 3" );
        nesneUret("edittext","edit text 1");
        nesneUret("button","Buton 4" );
        nesneUret("button","Buton 5" );
        nesneUret("button","Buton 6" );
        nesneUret("checkbox", "checkbox 2");
        nesneUret("button","Buton 7" );
        nesneUret("edittext","edit text 3");
        nesneUret("button","Buton 8" );


    }

    @Override
    public void onClick(View v) {

        Toast.makeText(getApplicationContext(), "butona tıklandı", Toast.LENGTH_LONG).show();

    }
}
