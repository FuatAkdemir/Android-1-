package com.example.imageintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    Intent intent = new Intent(getApplicationContext(), DetayActivity.class);

    public void ButonaTikla(View v){
        if(v.getId() == R.id.ivAnB){
            intent.putExtra("sanatçı", "Above and Beyond");
            intent.putExtra("resim", R.drawable.aboveandbeyond);
        }
        else if(v.getId() == R.id.ivAnF){
            intent.putExtra("sanatçı", "Aly and Fila");
            intent.putExtra("resim", R.drawable.alyanfila);

        }
        else if(v.getId() == R.id.ivFC){
            intent.putExtra("sanatçı", "Ferry Corsten");
            intent.putExtra("resim", R.drawable.ferrycorsten);

        }
        else if(v.getId() == R.id.ivAvB){
            intent.putExtra("sanatçı", "Armin van Buuren");
            intent.putExtra("resim", R.drawable.armin1);

        }

        startActivity(intent);


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);







    }
}
