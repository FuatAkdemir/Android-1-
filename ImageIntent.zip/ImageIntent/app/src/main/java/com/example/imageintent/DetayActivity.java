package com.example.imageintent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class DetayActivity extends AppCompatActivity {

    ImageView ivDetay;
    TextView tvDetay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay);

        ivDetay = findViewById(R.id.ivDetay);
        tvDetay = findViewById(R.id.tvDetay);

        String sanatci = getIntent().getStringExtra("sanatçı");
        int resimId = getIntent().getIntExtra("resim", -1);
        tvDetay.setText(sanatci);       // 2. yoldaböyle kullanırız.

        if(resimId != -1){

        }

        this.setTitle(sanatci);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true); // toolbar'a GERİ butonu eklemek istiyorsak bunu eklememiz lazım.




/*

        switch (sanatci){
            case "Above and Beyond":
                ivDetay.setImageResource(R.drawable.aboveandbeyond);
                break;

            case "Armin van Buuren":
                ivDetay.setImageResource(R.drawable.armin1);
                break;

            case "Aly and Fila":
                ivDetay.setImageResource(R.drawable.alyanfila);
                break;

            case "Ferry Corsten":
                ivDetay.setImageResource(R.drawable.ferrycorsten);
                break;
        }
*/

/*
        // 3. yol
        switch (sanatci){
            case "Above and Beyond":
                tvDetay.setText("Above and Beyond detay");
                ivDetay.setImageResource(R.drawable.aboveandbeyond);

                break;

            case "Armin van Buuren":
                tvDetay.setText("Armin van Buuren detay");
                ivDetay.setImageResource(R.drawable.armin1);

                break;

            case "Aly and Fila":
                tvDetay.setText("Aly and Fila detay");
                ivDetay.setImageResource(R.drawable.alyanfila);

                break;

            case "Ferry Corsten":
                tvDetay.setText("Ferry Corsten detay");
                ivDetay.setImageResource(R.drawable.ferrycorsten);

                break;

        }

*/

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == android.R.id.home){
            finish();   // Bulunduğu activity sayfasını kalıcı olarakkapatır.
        }

        return super.onOptionsItemSelected(item);

    }



}
