package com.example.resimbackground.Model;

public class Kategori {

    private int id;
    private String baslik;
    private int resimId;


    public Kategori() {

    }

    public Kategori(int id, String baslik, int resim) {
        this.id = id;
        this.baslik = baslik;
        this.resimId = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public int getResim() {
        return resimId;
    }

    public void setResim(int resim) {
        this.resimId = resim;
    }



}

