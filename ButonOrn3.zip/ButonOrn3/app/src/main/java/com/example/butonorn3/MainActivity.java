package com.example.butonorn3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.btn1){
            Toast.makeText(getApplicationContext(), "1. buton", Toast.LENGTH_LONG).show();

        }else if(v.getId() == R.id.btn2){
            Toast.makeText(getApplicationContext(), "2. buton", Toast.LENGTH_LONG).show();

        }else if(v.getId() == R.id.btn3){
            Toast.makeText(getApplicationContext(), "3. buton", Toast.LENGTH_LONG).show();

        }




    }

    Button btn1, btn2, btn3;



}
